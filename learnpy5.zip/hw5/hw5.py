import pandas as pd, numpy as np
from datetime import datetime

def get_data2():
    # Since df is just an intermediate, I don't really need to make the nice column labels, but I gotta love it...
    fname = 'N_seaice_extent_daily_v3.0.csv'
    df = pd.read_csv(fname, skiprows=2, names=[0, 1, 2, 'Extent'], 
                     usecols=[0, 1, 2, 3], parse_dates={'Dates': [0, 1, 2]}, header=None)
    s = df['Extent'] # s will have a name ('Extent'), but we don't care
    #s.name = None # not necessary, but gets rid of the name
    s.index = df['Dates'] # apparently, pandas doesn't give the index a name in this instance (???)
    return s.reindex(pd.date_range(s.index[0], s.index[-1]))
    '''
    # Use .values, otherwise you get the column name in there, not to mention indices
    return pd.Series(df['Extent'].values, 
        df['Dates']).reindex(pd.date_range(df.iloc[0, 0], df.iloc[-1, 0]))
    '''

def get_data():
    # Since df is just an intermediate, I don't really need to make the nice column labels, but I gotta love it...
    fname = 'N_seaice_extent_daily_v3.0.csv'
    ts = pd.read_csv(fname, skiprows=2, usecols=[0, 1, 2, 3],  
                     parse_dates={'Dates': [0, 1, 2]}, 
                     header=None, squeeze=True, index_col='Dates')
    #ts.index.name = None # if you want to get rid of the index name
    # to do in one line, pass in datetime objects for the specific dates
    return ts.reindex(pd.date_range(ts.index[0], ts.index[-1]))

def clean_data(ts):
    # first take care of the every other day issue in the earlier data
    # by filling in the missing data with the mean of the days before and after
    for i in range(len(ts)): 
        if pd.isnull(ts[i]): # should be doing ave +-5 years
            ts[i] = (ts[i - 1] + ts[i + 1]) / 2 # won't change anything if either is NaN
    # now deal with the end 1987-start 1988 gap by meaning the pre- and post- years
    for i in range(len(ts)): 
        if pd.isnull(ts[i]):
            '''
            previous_year = datetime(ts.index[i].year - 1, ts.index[i].month, ts.index[i].day)
            next_year = datetime(ts.index[i].year + 1, ts.index[i].month, ts.index[i].day)
            ts[i] = (ts[previous_year] + ts[next_year]) / 2
            ''' # should be doing ave +-5 years
            ts[i] = (ts[i - 365] + ts[i + 366]) / 2 # 366 because 1988 was a leap year

def get_column_labels2():
    # ignore the extra day in leap years
    columns = []
    for i in range(1, 13): # this will be a function
        if i == 2:
            last = 29
        elif i in [4, 6, 9, 11]:
            last = 31
        else:
            last = 32
        for j in range(1, last):
            #columns.append('{:02d}'.format(i) + '{:02d}'.format(j))
            columns.append(str(i).zfill(2) + str(j).zfill(2))
    return columns

def get_column_labels():
    '''
    Got this one from Josh - any non-leap year will work
    '''
    return pd.date_range('2015-01-01', '2015-12-31').strftime('%m%d').tolist() 

def extract_df(ts):    
    '''
    We have a time series that we are going to turn into a matrix.
    Strategy: make a frame with column and row labels but empty data,
    then fill it in.
    '''
    # ignore 1978, 2020 (for now)
    df = pd.DataFrame(index=list(range(1979, 2020)), columns=get_column_labels(), 
                      dtype=np.float64)
    for year in df.index:
        for mmdd in df.columns:
            df.loc[year, mmdd] = ts[datetime(year, int(mmdd[:2]), int(mmdd[2:]))]
    return df

def is_leap_year(year):
    return year % 4 == 0 and year % 100 != 0 or year % 4 == 0
    
def extract_2020(ts):
    dt = ts.index[-1]
    if is_leap_year(dt.year) and (dt.month > 2 or dt.month == 2 and dt.day == 29):
        return ts[datetime(2020, 1, 1):].drop(datetime(dt.year, 2, 29))
    return ts[datetime(2020, 1, 1):]

def extract_2019_2(ts):
    return ts[ts.index.year == 2020]

def main():
    ts = get_data() # ts is a Series
    #ts.to_pickle("raw_data.pkkl") # get rid of the extra k
    clean_data(ts)
    #ts.to_pickle("clean_data.pkkl") # get rid of the extra k
    df = extract_df(ts)
    #df.to_pickle("data_79_19.pkkl") # get rid of the extra k
    ##df.to_csv('data_79_18_correct.csv')
    df.to_csv('data_79_19.csv')
    ts_2020 = extract_2020(ts)
    #ts_2020.to_pickle('data_2020.pkkl') # get rid of the extra k
    ##ts_2019.to_csv('data_2019_correct.csv')
    ts_2020.to_csv('data_2020.csv', header=False)
    
if __name__ == '__main__':
    main()
