import pandas as pd, numpy as np, json
import matplotlib.pyplot as plt

'''
When first creating in June, NSIDC had the data split between files that 
ran 1978 through 2014 and 2015 to now.  When updating late September, 
2015 had been moved into the first file (...final) and the second (...nrt)
contained only 2016.  So code adjusted in places.  Expect similar next year, 
perhaps.  What actually happened, 2017, is that it's now all one file.

y16_frame used to be called y1516_frame before files updated.
'''

# cut-and-paste from hw4:
def get_column_labels():
    '''
    Got this one from Josh
    '''
    return pd.date_range('2015-01-01', '2015-12-31').strftime('%m%d').tolist() 

def get_2020():
    '''
    This helper function is called from 2 of the other fns.
    This will need to be modified for Fall semester in leap years.
    '''
    # returns a Series
    ''' F20: last day is 0831 '''
    index = get_column_labels() # this doesn't include '0229'
    index = index[:index.index('0831') + 1]
    ts = pd.read_csv('data_2020.csv', header=None)
    #return pd.Series(list(y2016.values[:59]) + list(y2016.values[60:]), index) # leap year
    return pd.Series(ts[1].values, index)

def extract_fig_1_frame(y79_y19_frame):
    '''
    f1f = pd.DataFrame(index=['mean', 'two_s'], columns=y79_y16_frame.columns)
    f1f.loc['mean'] = y79_y16_frame.mean()
    # should be ddof=0, but no one would actually use that
    f1f.loc['two_s'] = 2 * y79_y16_frame.std(ddof=1)
    return f1f
    '''
    return pd.DataFrame([y79_y19_frame.mean(), 2 * y79_y19_frame.std(ddof=1)], 
        ['mean', 'two_s'], y79_y19_frame.columns)
    
def make_fig_1(f1f, y79_y19_frame):
    '''
    Switch this from axes methods to pyplot functions.

    The mean line and the 2-sigma gray area allows us to see how unusual current data is visually.
    A data point should lie in the 2-sigma area ~95% of the time.
    The record low year also gives us a reference point.
    '''
    f1f.loc['mean'].plot(label='mean')
    #ax = plt.gca()
    plt.ylabel(r"NH Sea Ice Extent ($10^6$ km$^2$)", fontsize=24) # put units !  In parens
    x = np.arange(365)
    # do this without the astype to show things go wrong:
    y1 = (f1f.loc['mean'] + f1f.loc['two_s']).values.astype(float)
    y2 = (f1f.loc['mean'].values - f1f.loc['two_s'].values).astype(float)
    #plt.plot(x, y1)
    plt.fill_between(x, y1, y2, color='lightgray', label=r'$\pm$2 std devs')
    y79_y19_frame.loc[2012].plot(linestyle='--', label='2012') # Are max and min extent correlated for a given year?
    #xtl = [tick_label.get_text() for tick_label in ax.get_xticklabels()]
    # Finally figured out how to adjust the ticklabels with just plt, but it's a pain
    # And not sure why its actually different though the docs claim otherwise
    locs, labels = plt.xticks()
    labels = [label.get_text() for label in labels]
    get_2020().plot(label='2020')
    plt.xticks(locs[1:-1], labels[1:-1]) # here's the weirdness.
    # Why does that need the slice but ax.set_xticklabels doesn't?
    #ax.set_xticklabels(xtl)
    plt.xlim(0, 365)
    plt.legend()

def extract_fig_2_frame(y79_y19_frame):
    decades_frame = pd.DataFrame(index=['1980s', '1990s', '2000s', '2010s'], columns=y79_y19_frame.columns)
    decades_frame.loc['1980s'] = y79_y19_frame.loc[1980:1989].mean()
    decades_frame.loc['1990s'] = y79_y19_frame.loc[1990:1999].mean()
    decades_frame.loc['2000s'] = y79_y19_frame.loc[2000:2009].mean()
    decades_frame.loc['2010s'] = y79_y19_frame.loc[2010:].mean()
    return decades_frame
    
def make_fig_2(f2f):
    '''
    What does this plot illustrate?  Are winter and summer behaving the same?
    Next assignment focuses on this.
    '''
    f2f.loc['1980s'].plot(linestyle='--', label='1980s')
    f2f.loc['1990s'].plot(linestyle='--', label='1990s')
    f2f.loc['2000s'].plot(linestyle='--', label='2000s')
    f2f.loc['2010s'].plot(linestyle='--', label='2010s')
    ax = plt.gca()
    ax.set_ylabel(r"NH Sea Ice Extent ($10^6$ km$^2$)", fontsize=24) # put units!  In parens
    #ax.yaxis.label.set_fontsize(24)
    xtl = [tick_label.get_text() for tick_label in ax.get_xticklabels()]
    get_2020().plot(label='2020')
    ax.set_xticklabels(xtl)
    plt.xlim(0, 365)
    ax.legend(loc='best')

def main(): 
    # When we read the original data file, there was no index col
    # When we wrote this one to csv, there was, so we need to tell
    # Python that this time.
    y79_y19_frame = pd.read_csv('data_79_19.csv', index_col=0)
    
    #get_2020().to_pickle('ice_2020.pkl') # F18
    
    f1f = extract_fig_1_frame(y79_y19_frame)
    #f1f.to_pickle('fig1_frame.pkl')

    f2f = extract_fig_2_frame(y79_y19_frame)
    #f2f.to_pickle('fig2_frame.pkl')
    
    # No points for either of these unless the frame tests pass because they can't be right
    make_fig_1(f1f, y79_y19_frame)
    plt.figure() # explain why we need this in class
    make_fig_2(f2f)
    plt.show()

    
if __name__ == '__main__':
    main()
