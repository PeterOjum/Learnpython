import pandas as pd, numpy as np, json, math, sys
import matplotlib.pyplot as plt
import statsmodels.api as sm

#---- UPDATE LINES 82 AND 103 EACH YEAR ----#

'''
The Anomaly; Making Predictions

We saw in the example script we did in class that the mean state of the Arctic
will be ice-free in 2212 according to the linear model we derived from the data.
Ice minimum occurs annually in September.  When will Sept become ice-free?
What about March, the annual maximum?  Are they changing at the same rate?
Let's take a look now.

After: Antarctic sea ice.

When I say a line is a better model for Arctic Sea Ice Extent, what do 
I mean?  I mean that it makes better predictions of what will happen in the
future.  (From a technical point of view, it has smaller errors.  i.e. fits
the data better.)  The September sea ice next year is extremely likely to 
be closer to the line than the mean.

Revisiting hw5, fig 1: after what we've learned, is std dev the best 
measure of variability in Arctic Sea Ice Extent?  No RMSE is better.  
Because a line is a better model. Sd overestimates variability.

What possible problems are there with our predictions?  Nonlinear response
of ice to warming.  Changes in human behavior.

Compare the two figures.  How are the curves in Figure 1 related to the 
curves in Figure 2?  They are exactly the same shape, we have just subtracted
a constant from all of the y-values.  Why do they look different?  Because so
much more of the number of line is represented along the y-axis of Figure 1.
Therefore, the curves look squished vertically relative to Figure 2.  What's the
point of plotting the anomaly?  Figure 2 shows much more clearly how different 
the behavior is in summer vs. winter.  You can see much more clearly that
summer sea ice is diminishing much more rapidly than winter sea ice.
'''

def get_Mar_Sept_frame():
    years_frame = pd.read_csv('data_79_19.csv', index_col=0)
    # will need to illustrate getting the mean of a row
    years_frame['March_means'] = years_frame.loc[:, '0301':'0331'].mean(axis=1)
    years_frame['March_anomalies'] = years_frame['March_means'] - years_frame['March_means'].mean() 
    years_frame['September_means'] = years_frame.loc[:, '0901':'0930'].mean(axis=1)
    years_frame['September_anomalies'] = years_frame['September_means'] - years_frame['September_means'].mean()
    return years_frame.loc[:, 'March_means':]

def get_ols_parameters(series):
    '''
    This calculates least squares for a series where the x values are the index and the
    ys are the data.
    '''
    xs = sm.add_constant(series.index.values) # necessary to get the intercept
    model = sm.OLS(series, xs)
    results = model.fit()
    # return slope, intercept, R^2, and p-value
    # print(type(results.params)) # a Series
    return [results.params['x1'], results.params['const'], results.rsquared, results.pvalues['x1']]

def make_prediction(params, description='x-intercept:', x_name='x', y_name='y', ceiling=False):
    '''
    Gets the x-intercept for an ols line.
    '''
    intercept = math.ceil(-params[1] / params[0]) if ceiling else -params[1] / params[0]
    print(description, intercept)
    # The following will print as dd.0 if params[2] is type np.float64.  Go figure.
    print(str(round(params[2] * 100)) + '% of variation in', y_name, 'accounted for by', x_name, '(linear model)')
    print('Significance level of results:', 
        str(round(params[3] * 100, 1)) + '%')
    if params[3] <= 0.05:
        print('This result is statistically significant.')
    else:
        print('This result is not statistically significant.')
    
def make_fig_1(March_September):
    '''
    Depends on get_ols_parameters.
    Visually, how well does the line fit?
    '''
    ax = March_September['March_means'].plot()
    March_September['September_means'].plot()
    ax.set_ylabel(r"NH Sea Ice Extent ($10^6$ km$^2$)", fontsize=24) # put units !  In parens
    #ax.yaxis.label.set_fontsize(24)
    #---- UPDATE THIS LINE EACH YEAR ----#
    xs = np.arange(1979, 2020)
    March_params = get_ols_parameters(March_September['March_means'])
    ys = March_params[0] * xs + March_params[1]
    plt.plot(xs, ys)
    September_params = get_ols_parameters(March_September['September_means'])
    ys = September_params[0] * xs + September_params[1]
    plt.plot(xs, ys)
    plt.xlim(1979, 2019)

def make_fig_2(March_September):
    '''
    Doing the anomaly allows easier comparison of the different Series.
    Easier to see that summer is changing much faster than winter.
    The mean becomes 0.
    '''
    ax = March_September['March_anomalies'].plot()
    March_September['September_anomalies'].plot()
    ax.set_ylabel(r"NH Sea Ice Extent ($10^6$ km$^2$)", fontsize=24) # put units !  In parens
    #ax.yaxis.label.set_fontsize(24)
    #---- UPDATE THIS LINE EACH YEAR ----#
    xs = np.arange(1979, 2020)
    March_params = get_ols_parameters(March_September['March_anomalies'])
    ys = March_params[0] * xs + March_params[1]
    plt.plot(xs, ys)
    September_params = get_ols_parameters(March_September['September_anomalies'])
    ys = September_params[0] * xs + September_params[1]
    plt.plot(xs, ys)
    plt.title('The Anomaly')
    ax.title.set_fontsize(24)
    plt.xlim(1979, 2019)

def main(): 
    March_September = get_Mar_Sept_frame()
    # print(March_September)
    # March_September.to_pickle('ms.pkl')
    March_params = get_ols_parameters(March_September['March_means'])
    September_params = get_ols_parameters(March_September['September_means'])
    '''
    print(March_params)
    print(get_ols_parameters(March_September['March_anomalies']))
    print(September_params)
    print(get_ols_parameters(March_September['September_anomalies']))
    '''
    # When grading make sure you see the predictions output: -20 if not
    # It should print to the screen when the test calls main.  Something wrong if not.
    make_prediction(March_params, 'Ice-free March in year', 'time', 'Arctic sea ice', True)
    print()
    make_prediction(September_params, 'Ice-free September in year', 'time', 'Arctic sea ice', True)

        # -10 points for either of these unless the frame test passes because they can't be right
    make_fig_1(March_September)
    plt.figure() # explain why we need this in class
    make_fig_2(March_September)

    plt.show()
    
if __name__ == '__main__':
    main()
