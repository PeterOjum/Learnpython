Adjust the search terms in get_data.py and run it.

Use reformat.py to make it easier to look at what
you have wrought.

F20: First run 9/27 before first debate, 9/29.
