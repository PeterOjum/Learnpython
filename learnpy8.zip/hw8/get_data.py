'''
I am attempting to retrieve the full text of tweets.

At first I only avoided emails from the candidate's own acct.
Then I realized I needed to x both, but it was too late for the
pre-debate tweets, so I cleaned them afterward with clean_pre.py
This is fixed now
'''

'''
Would be more flexible if it used command line args to pick the files.
'''

'''
Should combine with reformat.py.
'''

'''
For documentation on formulating queries:
https://developer.twitter.com/en/docs/tweets/search/guides/standard-operators
https://developer.twitter.com/en/docs/tweets/search/api-reference/get-search-tweets
https://developer.twitter.com/en/docs/tweets/tweet-updates
https://developer.twitter.com/en/docs/tweets/post-and-engage/overview
'''

import json
from rmt_twitter_search import tsearch

r = tsearch('Trump -filter:retweets -from:JoeBiden -from:realDonaldTrump')
data = r.json()
with open('trump_tweets_raw.json', 'w') as fp:
    json.dump(data, fp)
tweet_list = data['statuses']
with open('trump_tweets.json', 'w') as fp:
    json.dump([t['full_text'] for t in tweet_list], fp)

r = tsearch('Biden -filter:retweets -from:JoeBiden -from:realDonaldTrump')
data = r.json()
with open('biden_tweets_raw.json', 'w') as fp:
    json.dump(data, fp)
tweet_list = data['statuses']
with open('biden_tweets.json', 'w') as fp:
    json.dump([t['full_text'] for t in tweet_list], fp)








