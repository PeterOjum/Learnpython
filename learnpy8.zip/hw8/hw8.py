import json
import pandas as pd
import matplotlib.pyplot as plt
from textblob import TextBlob as tb

'''
two runs of get_data.py
'''

def get_sentiment(fname):
    with open(fname) as fp:
        tweet_list = json.load(fp)
    blobs = [tb(t) for t in tweet_list]
    polarities = pd.Series([blob.polarity for blob in blobs if not (blob.polarity == blob.subjectivity == 0.0)])
    return [polarities.mean(), polarities.std(ddof=1)]
    
def get_ct_sentiment_frame():
    index = ['Trump', 'Biden']
    columns = ['pre_mean', 'pre_std', 'post_mean', 'post_std'] # left over, should have changed
    trump = get_sentiment('trump_tweets0927.json') + get_sentiment('trump_tweets0930.json')
    biden = get_sentiment('biden_tweets0927.json') + get_sentiment('biden_tweets0930.json')
    return pd.DataFrame([trump, biden], index, columns)
    
def make_fig3(df):
    '''
    The actual hw function, make_fig, is below.
    
    This and make_fig2 no longer look like what they used to -
    defaults have changes a lot.
    
    An easy version with subplots.  
    '''
    errors = df[['pre_std', 'post_std']]
    errors.columns = ['pre_mean', 'post_mean'] # index and columns must match data df 
    ax = df[['pre_mean', 'post_mean']].plot.bar(subplots=True, layout=[1, 2], 
        legend=False, yerr=errors)
    # ax is a 2D array of subplots
    ax[0, 0].set_ylabel('Polarity', fontsize=24)
    ax[0, 0].set_title('Pre-debate', fontsize=24)
    ax[0, 1].set_title('Post-debate', fontsize=24)
    
def make_fig2(df):
    '''
    This one's getting close, but I've found an easier way to 
    get something nice, albeit with less control.  Still subplots.
    '''
    ax = df[['pre_mean', 'post_mean']].plot.bar(subplots=True, layout=[1, 2], 
        legend=False)
    # ax is a 2D array of subplots
    ax[0, 0].set_ylabel('Polarity', fontsize=24)
    ax[0, 0].set_title('Pre-debate', fontsize=24)
    adjust_bars(ax[0, 0], df['pre_std'])
    ax[0, 1].set_title('Post-debate', fontsize=24)
    adjust_bars(ax[0, 1], df['post_std'])
    
def adjust_bars(ax, errors):
    trump_bar = ax.containers[0][0] # a Rectangle object
    # if there were error bars made in the call to bar, the Rectangle would
    # be in ax.containers[1][0], the error bars would be here, i.e. [0][0].
    trump_bar.set_color('g') # this carries over into the next bars drawn
    trump_bar.set_width(0.75)
    x = trump_bar.get_x()
    ax.set_xticks([x + 0.375, x + 1.025])
    ax.errorbar(x + 0.375, trump_bar.get_height(), errors['trump'], color='g')
    biden = ax.containers[0][1] # a Rectangle object
    biden_bar.set_color('b') # get back to blue
    biden_bar.set_x(x + 0.75)
    biden_bar.set_width(0.75)
    ax.errorbar(x + 1.025, biden_bar.get_height(), errors['biden'], color='b')
   
def make_fig(df):
    ''' The actual hw function. '''
    data = df[['pre_mean', 'post_mean']].T
    errors = df[['pre_std', 'post_std']].T
    data.index = errors.index = ['Trump-Biden pre-debate', 'Trump-Biden post-debate']
    data.columns = errors.columns = [0, 1]
    ax = data.plot.bar(legend=False, yerr=errors, capsize=10, 
        rot=0, fontsize=18, color=['b', 'g'],  
        ec=['black', 'black'], figsize=(10, 6))
    ax.set_facecolor("lavenderblush") # #FFF0F5
    plt.gcf().set_facecolor('black')
    ax.set_ylabel("Sentiment", fontsize=24)
    ax.xaxis.label.set_color('red')
    ax.yaxis.label.set_color('red')
    for spine in ax.spines:
        ax.spines[spine].set_color('red')
        
    # Set the ticks to be red
    for axis in ('x', 'y'):
        ax.tick_params(axis=axis, color='r')

    # Set the tick labels to be red
    for tl in ax.get_yticklabels():
        tl.set_color('r')
    for tl in ax.get_xticklabels():
        tl.set_color('r')

def main():

    '''
    # for hw8_test.py
    print(get_sentiment('trump_tweets0927.json'))
    print(get_sentiment('trump_tweets0930.json'))
    print(get_sentiment('biden_tweets0927.json'))
    print(get_sentiment('biden_tweets0930.json'))
    '''
    df = get_ct_sentiment_frame()
    #df.to_pickle('sm.pkl') # for hw8_test.py
    print()
    ########## S20: forgot to add this to the spec:
    print(df) # copy this into the spec
    make_fig(df)

    plt.show()

if __name__ == '__main__':
    main()







