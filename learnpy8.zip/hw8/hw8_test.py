from hw8 import *
import hw8
import unittest, json, numpy as np, pandas as pd, io
from compare_pandas import *
from contextlib import redirect_stdout

''' 
Auxiliary files needed:
    compare_pandas.py
    sm.pkl
The following files are needed by hw7 and so are also necessary:
    trump_tweets0927.json, trump_tweets0930.json
    biden_tweets0927.json, biden_tweets0930.json
'''

class TestFns(unittest.TestCase):
    def test_get_sentiment(self):
        params = [
            [0.14629802342387793, 0.2951989765283141],
            [0.06715949142846463, 0.36049161019790876],
            [0.0660260206901998, 0.31048037504855064],
            [0.06786244373804763, 0.2991233400334335]
            ]
        self.assertTrue(compare_lists(params[0], get_sentiment('trump_tweets0927.json')))
        self.assertTrue(compare_lists(params[1], get_sentiment('trump_tweets0930.json')))
        self.assertTrue(compare_lists(params[2], get_sentiment('biden_tweets0927.json')))
        self.assertTrue(compare_lists(params[3], get_sentiment('biden_tweets0930.json')))
   
    def test_get_ct_sentiment_frame(self):
        correct = pd.read_pickle('sm.pkl')
        self.assertTrue(compare_frames(correct, get_ct_sentiment_frame(), 0.005))
   
def main():
    test = unittest.defaultTestLoader.loadTestsFromTestCase(TestFns)
    results = unittest.TextTestRunner().run(test)
    print('Correctness score = ', str((results.testsRun - len(results.errors) - len(results.failures)) / results.testsRun * 60) + ' / 60')
    hw8.main()
    
if __name__ == "__main__":
    main()