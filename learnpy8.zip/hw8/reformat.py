import json
'''
This was for me; I did not provide it to the
students.  Easier to see what I had.

Translate a json string in a file of tweet texts into a
more user-friendly text file.

Would be more flexible if it used command line args to pick the files.
'''

with open('trump_tweets0930.json') as fp:
    tweets = json.load(fp)

with open('trump_tweets0930.txt', 'wb') as fp:    
    for t in tweets:
        fp.write(t.encode() + b'\n\n')
        fp.write(('-' * 80).encode() + b'\n\n')

with open('biden_tweets0930.json') as fp:
    tweets = json.load(fp)

with open('biden_tweets0930.txt', 'wb') as fp:    
    for t in tweets:
        fp.write(t.encode() + b'\n\n')
        fp.write(('-' * 80).encode() + b'\n\n')
"""        
with open('sinema_tweets_run437pm.json') as fp:
    tweets = json.load(fp)

with open('sinema_tweets_run437pm.txt', 'wb') as fp:    
    for t in tweets:
        fp.write(t.encode() + b'\n\n')
        fp.write(('-' * 80).encode() + b'\n\n')
with open('mcsally_tweets_run437pm.json') as fp:
    tweets = json.load(fp)

with open('mcsally_tweets_run437pm.txt', 'wb') as fp:    
    for t in tweets:
        fp.write(t.encode() + b'\n\n')
        fp.write(('-' * 80).encode() + b'\n\n')
"""        

   