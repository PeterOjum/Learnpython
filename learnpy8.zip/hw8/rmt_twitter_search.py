import requests
from requests_oauthlib import OAuth1 
from urllib.parse import quote

def tsearch(keyword, count=100):
    ''' 100 is max allowed, default is 15. '''
    my_API_key = "2dXYjmu04wtbl3fJG0gqKZhnW"
    my_API_key_secret = "yZairKVZxYyqGYRZL0aqtoJ8EjK2bT3226JS0VLGpFvMuR1RrJ"
    my_access_token = "475881586-InmXEeJm9GcaDRtiKuZxUEkaAVOfOgbgiWx9ubjM"
    my_access_token_secret = "skA6vIgR8JIzHiLzYUCChKIjpVj3Klz5ypjEdvSVyQH8a"
    auth = OAuth1(my_API_key, my_API_key_secret, my_access_token, my_access_token_secret)
    url = ("https://api.twitter.com/1.1/search/tweets.json?q=" + quote(keyword) + 
      '&count=' + str(count) + '&tweet_mode=extended')
    r = requests.get(url, auth=auth)
    r.close() # good hygiene - don't want to leave connections open for too long.
    # They might get closes from the other end, causing future calls to fail.
    # Better to make a new one each time through.
    return r
    #return requests.get(url, auth=auth)










